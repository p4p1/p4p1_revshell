#ifndef _COMMAND_H_
#define _COMMAND_H_

/* custom commands of p4p1 are found here.
*/

#include "../main.h"
#include "win_api.h"

int cd(char *);
int wget(char *);
int get_file(char *, int );

#endif
