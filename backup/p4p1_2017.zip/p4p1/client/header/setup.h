#ifndef _SETUP_H_
#define _SETUP_H_

/* setup header for the entire reverse shell
*/

#include "../main.h"
#include "win_api.h"

int setup(struct main_struct *);

#endif
