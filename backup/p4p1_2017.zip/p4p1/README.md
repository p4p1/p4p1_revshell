# p4p1

[how to use guide](https://github.com/p4p1/p4p1/wiki/New-version)
[latest release](https://github.com/p4p1/p4p1/releases)

## Description:
This software is a reverse shell that sits on a windows box. This is custom
built so should be well hidden. It has several features listed bellow.
You can use it for remote access on your' box or to get access to a box that
you don't own.

### Features
1. open up a file in notepad to make user beleive it opened a text file
2. download file from the victim to you're box
3. download files from url to the victim box
4. custom ip port usage
5. server works on all os that have python2.7

