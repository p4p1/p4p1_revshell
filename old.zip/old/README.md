#p4p1
This is a simple remote administration tool to send commands to a client.<br />

How to install:<br />
To install p4p1 you need to be on mac or linux. If you are on one of the ubuntu varients its better(not obligatory).<br />
1/ download the repository<br />
2/ run the p4p1-i_Instaler as root and follow the steps<br />
<img src="https://github.com//p4p1/p4p1/blob/master/Documentation/Untitled.png?raw=true">


How To use With netcat:<br />

1/ put the exe in a windows computer<br />
2/ add a ip.cfg file in the same file as the exe with your ip<br />
3/ run nc -l 4441 on youre computer<br />
4/ Send in the 0 character to indicate to the exe you are using netcat<br />
5/ Start sending comands!!!<br />
<img src="https://github.com/p4p1/p4p1/blob/master/Documentation/Screen%20Shot%202016-10-14%20at%2001.02.24.png?raw=true" >

How to use with the ncurses client:<br />
1/ run ./p4p1-s_V[version_here] <br />
2/ wait for client to connect :) <br />
<img src="https://github.com/p4p1/p4p1/blob/master/Documentation/Untitled3.png?raw=true">
<img src="https://github.com/p4p1/p4p1/blob/master/Documentation/Untitled4.png?raw=true">

How to use with terminal client: <br />
1/ rn ./p4p1-s_V[version_here] -cli <br />
2/ Wait for client to connect again :) <br />
<img src="https://github.com/p4p1/p4p1/blob/master/Documentation/Untitled6.png?raw=true">
